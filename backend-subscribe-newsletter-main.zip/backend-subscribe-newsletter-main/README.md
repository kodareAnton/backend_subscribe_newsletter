# backend-subscribe-newsletter

Npm package :
npx express-generator --no-view
npm i cors
npm install mongodb
